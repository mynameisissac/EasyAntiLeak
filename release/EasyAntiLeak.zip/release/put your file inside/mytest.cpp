#include <iostream>
using namespace std; 




int main(){ 

    int* p = new int;

    return 0;
}